<?php

$con=mysqli_connect("localhost", "u856106684_hand", "hand123", "u856106684_hand");
mysqli_select_db($con,"tb_campeonato");

?>
<head>
	        <meta charset="utf8_general_ci">
        <title>Liga Universitária</title>
         <link rel="stylesheet" type="text/css" href="CSS/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="CSS/table.css">
        <link rel="stylesheet" type="text/css" href="CSS/tema.css">
        <link rel="stylesheet" type="text/css" href="CSS/botoes.css">
        <link rel="stylesheet" type="text/css" href="CSS/lista_de_noticias.css">
        <link rel="Shortcut icon" href="IMG/favicon.ico" />

</head>