<?php
include "headadmin.php";
include "head.php";
?>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/trevo1.png');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Tabela do Campeonato</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Classificação <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
    <center>
			<section class="ftco-section">
		<div class="container">
	
			<div class="col-md-7">
	          <div class="heading-section ftco-animate">
	            <div class="row">
	            	<div class="col-md-6 top-score pb-4 mb-1">
			    				<a href="jogosaltera.php"><div class="img" style="background-image: url(images/config.png);"></div>
			    				<div class="text text-center">
			    					<h3 class="mb-0">Resultado de Jogos</h3></a>
			    				</div>
		    				</div>
		    				<div class="col-md-6 top-score pb-4 mb-1">
			    				<a href="rodadaatt.php"><div class="img" style="background-image: url(images/config.png);"></div>
			    				<div class="text text-center">
			    					<h3 class="mb-0">Atualizar Rodadas</h3></a>
			    		
			    				</div>
		    				</div>
		    				<div class="col-md-6 top-score pb-4 mb-1">
			    				<a href="timeatt.php"><div class="img" style="background-image: url(images/config.png);"></div>
			    				<div class="text text-center">
			    					<h3 class="mb-0">Atualizar Times</h3></a>
			    		
			    				</div>
		    				</div>

		    				<div class="col-md-6 top-score pb-4 mb-1">
			    				<a href="jogadoratt.php"><div class="img" style="background-image: url(images/config.png);"></div>
			    				<div class="text text-center">
			    					<h3 class="mb-0">Atualizar Jogador</h3></a>
			    		
			    				</div>
		    				</div>
		    				</div>
		    				<div class="col-md-6 top-score pb-4 mb-1">
			    				<a href="jogadoradd.php"><div class="img" style="background-image: url(images/config.png);"></div>
			    				<div class="text text-center">
			    					<h3 class="mb-0">Adicionar Jogador</h3></a>
			    		
			    				</div>
		    				</div>
		    			
		    				
					</div>
				</div>
			</div>
 		</div>
	             				</div>
	         </section></center>
		
		<?php
    include "foot.php";
    ?>


